//
//  ViewController.swift
//  Swift Walking Calorie Counter
//
//  Created by John Bura on 10/20/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var txtDuration: UITextField!
    @IBOutlet weak var txtWeight: UITextField!
    @IBOutlet weak var txtSpeed: UITextField!
    @IBOutlet weak var txtGrade: UITextField!
    
    @IBOutlet weak var segMetricImperial: UISegmentedControl!
    
    @IBOutlet weak var lblCaloriesBurned: UILabel!
    
    var duration = ""
    var weight = ""
    var speed = ""
    var grade = ""
    
    var totalCaloriesBurned : Float = 0
    
    var isMetric = true
    var isImperial = false
    var firstUse = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func segMetricImperialACTION(sender: UISegmentedControl) {
        
        firstUse = false
        
        if segMetricImperial.selectedSegmentIndex == 0{
            isMetric = true
            isImperial = false
            
        }
        if segMetricImperial.selectedSegmentIndex == 1{
            isMetric = false
            isImperial = true
            
        }
        
        calculateCalories()
    }
    
    @IBAction func btnClear(sender: UIButton) {
    }

    @IBAction func btnCalculate(sender: UIButton) {
        calculateCalories()
    }
    
    func calculateCalories() -> Bool{
        duration = txtDuration.text
        weight = txtWeight.text
        speed = txtSpeed.text
        grade = txtGrade.text
        
        var fDuration = (duration as NSString).floatValue
        var fWeight = (weight as NSString).floatValue
        var fSpeed = (speed as NSString).floatValue
        var fGrade = (grade as NSString).floatValue
        
        if isMetric == true && firstUse == false{
            fWeight = fWeight * 0.45
            fSpeed = fSpeed * 1.6
            
        }
        
        if isImperial == true{
            
            fWeight = fWeight * 2.2
            fSpeed = fSpeed * 0.62

        }
        
        var MET : Float = ((0.175 * fSpeed) + (0.9 * fSpeed / fGrade) / 3.5)
        totalCaloriesBurned = fDuration * (MET * 3.5 * fWeight) / 200
        
        var formatCaloriesBurned : NSString = NSString(format: "%0.0f", totalCaloriesBurned)
        var formatWeight : NSString = NSString(format: "%0.0f", fWeight)
        var formatSpeed : NSString = NSString(format: "%0.0f", fSpeed)
        
        
        txtWeight.text = "\(formatWeight)"
        txtSpeed.text = "\(formatSpeed)"
        
        lblCaloriesBurned.text = "Total Burned: \(formatCaloriesBurned)"
        
        
        return true
    }
    

    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtDuration.resignFirstResponder()
        txtGrade.resignFirstResponder()
        txtSpeed.resignFirstResponder()
        txtWeight.resignFirstResponder()
    }
    
    
}

