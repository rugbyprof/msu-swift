//
//  ViewController.swift
//  Swift Startup Calculator
//
//  Created by John Bura on 9/22/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtStartUpCost: UITextField!
    @IBOutlet weak var txtMonthlyIncome: UITextField!
    @IBOutlet weak var txtBorrowingRate: UITextField!
    @IBOutlet weak var txtFixedMonthlyCost: UITextField!
    
    @IBOutlet weak var lblMonthsToPayBack: UILabel!
    @IBOutlet weak var lblTimeToSeeAReturn: UILabel!
    
    @IBOutlet weak var lblTotalStartupCosts: UILabel!
    @IBOutlet weak var lblProjectedYearlyIncome: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    
    var startupCosts = ""
    var monthlyIncome = ""
    var borrowingRate = ""
    var fixedMonthlyCosts = ""
    
    var monthsToPayBack : Float = 0
    var timeToSeeAReturn : Float = 0
    var totalYearlyStartupCosts : Float = 0
    var projectedYearlyIncome : Float = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading te view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose ofany resources that can be recreated.
    }

    @IBAction func btnCalculate(sender: UIButton) {
        calculateStartupCosts()
    }

    @IBAction func btnClear(sender: UIButton) {
        
        txtBorrowingRate.text = ""
        txtFixedMonthlyCost.text = ""
        txtMonthlyIncome.text = ""
        txtStartUpCost.text = ""
        
        lblMonthsToPayBack.text = "(months)"
        lblTimeToSeeAReturn.text = "(months)"
        lblTotalStartupCosts.text = "$$$$"
        lblProjectedYearlyIncome.text = "$$$$"
        
        lblMessage.text = "Are you profitable this year?"
    }
    
    func calculateStartupCosts() -> Bool{
        startupCosts = txtStartUpCost.text
        monthlyIncome = txtMonthlyIncome.text
        borrowingRate = txtBorrowingRate.text
        fixedMonthlyCosts = txtFixedMonthlyCost.text
        
        var fStartupCosts = (startupCosts as NSString).floatValue
        var fMonthlyIncome = (monthlyIncome as NSString).floatValue
        var fBorrowingRate = (borrowingRate as NSString).floatValue
        var fFixedMonthlyCosts = (fixedMonthlyCosts as NSString).floatValue

        var totalYearlyCosts : Float = (fStartupCosts * (fBorrowingRate / 100 + 1) + (fFixedMonthlyCosts * 12)) - (fMonthlyIncome * 12)
        
        monthsToPayBack = (fStartupCosts * (fBorrowingRate / 100 + 1)) / fMonthlyIncome
        timeToSeeAReturn = monthsToPayBack * 2
        projectedYearlyIncome = (fMonthlyIncome * 12) - totalYearlyCosts
        
        var formatTotalYearlyCosts : NSString = NSString(format: "%0.0f", totalYearlyCosts)
        var formatMonthsToPayBack : NSString = NSString(format: "%0.0f", monthsToPayBack)
        var formatTimeToSeeAReturn : NSString = NSString(format: "%0.0f", timeToSeeAReturn)
        var formatProjectedYearlyIncome : NSString = NSString(format: "%0.0f", projectedYearlyIncome)
  
        lblMonthsToPayBack.text = "\(formatMonthsToPayBack)"
        lblTimeToSeeAReturn.text = "\(formatTimeToSeeAReturn)"
        lblTotalStartupCosts.text = "\(formatTotalYearlyCosts)"
        lblProjectedYearlyIncome.text = "\(formatProjectedYearlyIncome)"
        
        if totalYearlyCosts <= 0 {
            
            lblMessage.text = "Yes you are profitiable this year"
        }
        else{
            lblMessage.text = "No you are not profitable this year"
        }
        
        return true
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtBorrowingRate.resignFirstResponder()
        txtFixedMonthlyCost.resignFirstResponder()
        txtMonthlyIncome.resignFirstResponder()
        txtStartUpCost.resignFirstResponder()
    }
}

