//
//  ViewController.swift
//  Swift Time Productivity app
//
//  Created by John Bura on 9/22/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtInternet: UITextField!
    @IBOutlet weak var txtYouTube: UITextField!
    @IBOutlet weak var txtCommuting: UITextField!
    @IBOutlet weak var txtSleeping: UITextField!
    @IBOutlet weak var txtVideoGames: UITextField!
    
    @IBOutlet weak var lblTotalHoursSpent: UILabel!
    
    @IBOutlet weak var lblWeekInternet: UILabel!
    @IBOutlet weak var lblWeekYouTube: UILabel!
    @IBOutlet weak var lblWeekCommuting: UILabel!
    @IBOutlet weak var lblWeekSleeping: UILabel!
    @IBOutlet weak var lblWeekGames: UILabel!
    
    @IBOutlet weak var lblMonthInternet: UILabel!
    @IBOutlet weak var lblMonthYouTube: UILabel!
    @IBOutlet weak var lblMonthCommuting: UILabel!
    @IBOutlet weak var lblMonthSleeping: UILabel!
    @IBOutlet weak var lblMonthGames: UILabel!
    
    @IBOutlet weak var lblYearInternet: UILabel!
    @IBOutlet weak var lblYearYouTube: UILabel!
    @IBOutlet weak var lblYearCommuting: UILabel!
    @IBOutlet weak var lblYearSleeping: UILabel!
    @IBOutlet weak var lblYearGames: UILabel!
    
    var timeInternet = ""
    var timeYouTube = ""
    var timeCommuting = ""
    var timeSleeping = ""
    var timeGames = ""
    
    var totalHoursSpent : Float = 0
    
    var weekInternet : Float = 0
    var weekYouTube : Float = 0
    var weekCommuting : Float = 0
    var weekSleeping : Float = 0
    var weekGames : Float = 0
    
    var monthInternet : Float = 0
    var monthYouTube : Float = 0
    var monthCommuting : Float = 0
    var monthSleeping : Float = 0
    var monthGames : Float = 0
    
    var yearInternet : Float = 0
    var yearYouTube : Float = 0
    var yearCommuting : Float = 0
    var yearSleeping : Float = 0
    var yearGames : Float = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnCalculate(sender: UIButton) {
        calculateHours()
    }
    
    @IBAction func btnClear(sender: UIButton) {
        txtCommuting.text = ""
        txtInternet.text = ""
        txtSleeping.text = ""
        txtVideoGames.text = ""
        txtYouTube.text = ""
        
        lblWeekInternet.text = "Hours"
        lblWeekYouTube.text = "Hours"
        lblWeekCommuting.text = "Hours"
        lblWeekSleeping.text = "Hours"
        lblWeekGames.text = "Hours"
        
        lblMonthInternet.text = "Hours"
        lblMonthYouTube.text = "Hours"
        lblMonthCommuting.text = "Hours"
        lblMonthSleeping.text = "Hours"
        lblMonthGames.text = "Hours"
        
        lblYearInternet.text = "Hours"
        lblYearYouTube.text = "Hours"
        lblYearCommuting.text = "Hours"
        lblYearSleeping.text = "Hours"
        lblYearGames.text = "Hours"
        
        lblTotalHoursSpent.text = "Total Hours Spent: (year)"
        
    }
    
    func calculateHours() -> Bool{
        timeInternet = txtInternet.text
        timeYouTube = txtYouTube.text
        timeCommuting = txtCommuting.text
        timeSleeping = txtSleeping.text
        timeGames = txtVideoGames.text
        
        var fTimeInternet = (timeInternet as NSString).floatValue
        var fTimeYouTube = (timeYouTube as NSString).floatValue
        var fTimeCommuting = (timeCommuting as NSString).floatValue
        var fTimeSleeping = (timeSleeping as NSString).floatValue
        var fTimeGames = (timeGames as NSString).floatValue
        
         weekInternet = fTimeInternet * 7
         weekYouTube = fTimeYouTube * 7
         weekCommuting = fTimeCommuting * 7
         weekSleeping = fTimeSleeping * 7
         weekGames = fTimeGames * 7
        
         monthInternet = fTimeInternet * 30
         monthYouTube = fTimeYouTube * 30
         monthCommuting = fTimeCommuting * 30
         monthSleeping = fTimeSleeping * 30
         monthGames = fTimeGames * 30
        
         yearInternet = fTimeInternet * 365
         yearYouTube = fTimeYouTube * 365
         yearCommuting = fTimeCommuting * 365
         yearSleeping = fTimeSleeping * 365
         yearGames = fTimeGames * 365
        
        
        var formatweekInternet : NSString = NSString(format: "%0.0f", weekInternet)
        var formatweekYouTube : NSString = NSString(format: "%0.0f", weekYouTube)
        var formatweekCommuting : NSString = NSString(format: "%0.0f", weekCommuting)
        var formatweekSleeping : NSString = NSString(format: "%0.0f", weekSleeping)
        var formatweekGames : NSString = NSString(format: "%0.0f", weekGames)
        
        var formatmonthInternet : NSString = NSString(format: "%0.0f", monthInternet)
        var formatmonthYouTube : NSString = NSString(format: "%0.0f", monthYouTube)
        var formatmonthCommuting : NSString = NSString(format: "%0.0f", monthCommuting)
        var formatmonthSleeping : NSString = NSString(format: "%0.0f", monthSleeping)
        var formatmonthGames : NSString = NSString(format: "%0.0f", monthGames)
        
        var formatYearInternet : NSString = NSString(format: "%0.0f", yearInternet)
        var formatyearYouTube : NSString = NSString(format: "%0.0f", yearYouTube)
        var formatyearCommuting : NSString = NSString(format: "%0.0f", yearCommuting)
        var formatyearSleeping : NSString = NSString(format: "%0.0f", yearSleeping)
        var formatyearGames : NSString = NSString(format: "%0.0f", yearGames)
        
        lblWeekInternet.text = "\(formatweekInternet)"
        lblWeekYouTube.text = "\(formatweekYouTube)"
        lblWeekCommuting.text = "\(formatweekCommuting)"
        lblWeekSleeping.text = "\(formatweekSleeping)"
        lblWeekGames.text = "\(formatweekGames)"
        
        lblMonthInternet.text = "\(formatmonthInternet)"
        lblMonthYouTube.text = "\(formatmonthYouTube)"
        lblMonthCommuting.text = "\(formatmonthCommuting)"
        lblMonthSleeping.text = "\(formatmonthSleeping)"
        lblMonthGames.text = "\(formatmonthGames)"
        
        lblYearInternet.text = "\(formatYearInternet)"
        lblYearYouTube.text = "\(formatyearYouTube)"
        lblYearCommuting.text = "\(formatyearCommuting)"
        lblYearSleeping.text = "\(formatyearSleeping)"
        lblYearGames.text = "\(formatyearGames)"
        
        totalHoursSpent = yearInternet + yearYouTube + yearGames + yearCommuting + yearSleeping
        
        lblTotalHoursSpent.text = "\(totalHoursSpent) Hours"
        
        return true
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtCommuting.resignFirstResponder()
        txtInternet.resignFirstResponder()
        txtSleeping.resignFirstResponder()
        txtVideoGames.resignFirstResponder()
        txtYouTube.resignFirstResponder()
    }

}

