//
//  ViewController.swift
//  Multiplication OSX in Swift
//
//  Created by John Bura on 11/12/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet weak var lblNumber1: NSTextField!
    @IBOutlet weak var lblNumber2: NSTextField!
    @IBOutlet weak var lblAnswer: NSTextField!
    
    @IBOutlet weak var lblCorrectIncorrect: NSTextField!
    @IBOutlet weak var lblTotalCorrect: NSTextField!
    
    @IBOutlet weak var btnAnswer0: NSButton!
    @IBOutlet weak var btnAnswer1: NSButton!
    @IBOutlet weak var btnAnswer2: NSButton!
    @IBOutlet weak var btnAnswer3: NSButton!
    
    var number1 = 0
    var number2 = 0
    var answer = 0
    
    var totalCorrect = 0
    var buttonAnswer = 0
    
    var button0Correct = false
    var button1Correct = false
    var button2Correct = false
    var button3Correct = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        gameLogic()
        // Do any additional setup after loading the view.
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    @IBAction func btnAnswer0ACTION(sender: NSButton) {
    }
    
    @IBAction func btnAnswer1(sender: NSButton) {
    }

    @IBAction func btnAnswer2ACTION(sender: NSButton) {
    }
    @IBAction func btnAnswer3ACTION(sender: NSButton) {
    }

    @IBAction func btnReset(sender: NSButton) {
    }
    
    func gameLogic() -> Bool {

        
        return true
    }
    
    
    
}

