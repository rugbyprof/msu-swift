//
//  ViewController.swift
//  Swift Millionaire app
//
//  Created by John Bura on 9/21/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var txtTotalSavings: UITextField!
    @IBOutlet weak var txtWeeklySavings: UITextField!
    @IBOutlet weak var txtAnnualReturn: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    
    @IBOutlet weak var lblTotalTime: UILabel!
    @IBOutlet weak var lblTotalAge: UILabel!
    
    var totalSavings = ""
    var  weeklySavings = ""
    var annualReturn = ""
    var age = ""
    
    var totalTime : Float = 0
    var toalAge : Float = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnCalculate(sender: UIButton) {
        calculateMillionaireSatus()
    }

    @IBAction func btnClear(sender: UIButton) {
        txtTotalSavings.text = ""
        txtWeeklySavings.text = ""
        txtAnnualReturn.text = ""
        txtAge.text = ""
        
        lblTotalTime.text = "Total Time"
        lblTotalAge.text = "Total Age"
        
    }
    
    func calculateMillionaireSatus() -> Bool{
        totalSavings = txtTotalSavings.text
        weeklySavings = txtWeeklySavings.text
        annualReturn = txtAnnualReturn.text
        age = txtAge.text
        
        var fTotalSavings = (totalSavings as NSString).floatValue
        var fWeeklySavings = (weeklySavings as NSString).floatValue
        var fAnnaulReturn = (annualReturn as NSString).floatValue / 100 + 1
        var fAge = (age as NSString).floatValue
        
        var millionDollars : Float = 1000000
        var months : Float = 0
        var years: Float = 0
        
        if fTotalSavings <= 1000000{
            
            for (var i : Float = millionDollars; i >= fTotalSavings; i--){
                fTotalSavings = fTotalSavings + (fWeeklySavings * 52 * fAnnaulReturn)
                months = months + 12
                years = (months / 12) + fAge
                
                var formatMonths : NSString = NSString(format: "%0.0f", months)
                var formatYears : NSString = NSString(format: "%0.0f", years)
                
                lblTotalTime.text = "\(formatMonths) Months"
                lblTotalAge.text = "\(formatYears) Yearls old"
                
            }
            
        }
        
        
        return true
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtAge.resignFirstResponder()
        txtAnnualReturn.resignFirstResponder()
        txtTotalSavings.resignFirstResponder()
        txtWeeklySavings.resignFirstResponder()
    }
}

