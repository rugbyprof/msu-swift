//
//  ViewController.swift
//  swift simple video app
//
//  Created by John Bura on 9/25/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit
import MediaPlayer


class ViewController: UIViewController {
    
    var width = 288
    var height = 200
    var x = 16
    var y = 50

    override func viewDidLoad() {
        super.viewDidLoad()
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnPlayVideo1(sender: AnyObject) {
     
     var url = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("1", ofType: "mp4")!)
        
        playMovie(url)
    }

    @IBAction func btnPlayVideo2(sender: UIButton) {
        var url = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("2", ofType: "mp4")!)
        
         playMovie(url)
    }
    @IBAction func btnPlayVideo3(sender: UIButton) {
        var url = NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("3", ofType: "mp4")!)
        
         playMovie(url)
    }
    
    func playMovie(videoURL: NSURL) -> Bool{
        var player = MPMoviePlayerController(contentURL: videoURL)
        player.view.frame = CGRect(x: x, y: y, width: width, height: height)
        
        player.movieSourceType = MPMovieSourceType.File
        
        self.view.addSubview(player.view)
        
        player.prepareToPlay()
        player.play()
        
        
        
        
        return true
    }

}

