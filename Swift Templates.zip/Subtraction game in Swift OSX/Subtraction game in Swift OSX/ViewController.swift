//
//  ViewController.swift
//  Subtraction game in Swift OSX
//
//  Created by John Bura on 11/12/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet weak var lblNumber1: NSTextField!
    @IBOutlet weak var lblNumber2: NSTextField!
    @IBOutlet weak var lblAnswer: NSTextField!
    
    @IBOutlet weak var lblCorrectIncorrect: NSTextField!
    @IBOutlet weak var lblTotalCorrect: NSTextField!
    
    @IBOutlet weak var btnAnswer0: NSButton!
    @IBOutlet weak var btnAnswer1: NSButton!
    @IBOutlet weak var btnAnswer2: NSButton!
    @IBOutlet weak var btnAnswer3: NSButton!
    
    var number1 = 0
    var number2 = 0
    var answer = 0
    
    var totalCorrect = 0
    var buttonAnswer = 0
    
    var button0Correct = false
    var button1Correct = false
    var button2Correct = false
    var button3Correct = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        gameLogic()
    }

    override var representedObject: AnyObject? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    @IBAction func btnAnswer0ACTION(sender: NSButton) {
        if button0Correct == true{
            lblCorrectIncorrect.stringValue = "Correct!"
            totalCorrect = totalCorrect + 1
            lblTotalCorrect.stringValue = "Total Correct: \(totalCorrect)"
        }
        else {
            lblCorrectIncorrect.stringValue = "Incorrect"
        }
        
        button0Correct = false
        gameLogic()
    }
    @IBAction func btnAnswer1ACTION(sender: NSButton) {
        if button1Correct == true{
            lblCorrectIncorrect.stringValue = "Correct!"
            totalCorrect = totalCorrect + 1
            lblTotalCorrect.stringValue = "Total Correct: \(totalCorrect)"
        }
        else {
            lblCorrectIncorrect.stringValue = "Incorrect"
        }
        
        button1Correct = false
        gameLogic()
    }
    
    @IBAction func bntAnswer2ACTION(sender: NSButton) {
        if button2Correct == true{
            lblCorrectIncorrect.stringValue = "Correct!"
            totalCorrect = totalCorrect + 1
            lblTotalCorrect.stringValue = "Total Correct: \(totalCorrect)"
        }
        else {
            lblCorrectIncorrect.stringValue = "Incorrect"
        }
        
        button2Correct = false
        gameLogic()
    }
    
    @IBAction func btnAnswer3ACTION(sender: NSButton) {
        if button3Correct == true{
            lblCorrectIncorrect.stringValue = "Correct!"
            totalCorrect = totalCorrect + 1
            lblTotalCorrect.stringValue = "Total Correct: \(totalCorrect)"
        }
        else {
            lblCorrectIncorrect.stringValue = "Incorrect"
        }
        
        button3Correct = false
        gameLogic()
    }

    
    @IBAction func btnReset(sender: NSButton) {
        lblCorrectIncorrect.stringValue = "Try again"
        gameLogic()
    }
    
    func gameLogic() -> Bool {
   
        number1 = Int(arc4random_uniform(10))
        number2 = Int(arc4random_uniform(9))
        
        buttonAnswer = Int(arc4random_uniform(3))
        
       
        
        if number1 < number2{
            number2 = Int(arc4random_uniform(3))
            
            if number2 > number1 {
                number2 = 0
            }

        }
        
        lblNumber1.stringValue = "\(number1)"
        lblNumber2.stringValue = "\(number2)"
        answer = number1 - number2
        
        var incorrectAnswer1 = Int(arc4random_uniform(10))
        var incorrectAnswer2 = Int(arc4random_uniform(10))
        var incorrectAnswer3 = Int(arc4random_uniform(10))
        
        if incorrectAnswer1 == answer || incorrectAnswer2 == answer || incorrectAnswer3 == answer{
            incorrectAnswer1 = 11
            incorrectAnswer2 = 12
            incorrectAnswer3 = 13
        }
        
        if incorrectAnswer1 == incorrectAnswer2 || incorrectAnswer1 == incorrectAnswer3{
            incorrectAnswer1 == 11
        }
        if incorrectAnswer2 == incorrectAnswer3{
            incorrectAnswer2 == 12
        }
        
        if buttonAnswer == 0 {
            btnAnswer0.title = "\(answer)"
            
            btnAnswer1.title = "\(incorrectAnswer1)"
            btnAnswer2.title = "\(incorrectAnswer2)"
            btnAnswer3.title = "\(incorrectAnswer3)"
            
            button0Correct = true
        }
        
        if buttonAnswer == 1 {
            btnAnswer1.title = "\(answer)"
            
            btnAnswer0.title = "\(incorrectAnswer1)"
            btnAnswer2.title = "\(incorrectAnswer2)"
            btnAnswer3.title = "\(incorrectAnswer3)"
            
            button1Correct = true
        }
        
        if buttonAnswer == 2 {
            btnAnswer2.title = "\(answer)"
            
            btnAnswer1.title = "\(incorrectAnswer1)"
            btnAnswer0.title = "\(incorrectAnswer2)"
            btnAnswer3.title = "\(incorrectAnswer3)"
            
            button2Correct = true
        }
        
        if buttonAnswer == 3 {
            btnAnswer3.title = "\(answer)"
            
            btnAnswer1.title = "\(incorrectAnswer1)"
            btnAnswer0.title = "\(incorrectAnswer2)"
            btnAnswer3.title = "\(incorrectAnswer3)"
            
            button3Correct = true
        }
        
        
        
        
        
        
        

        return true
    }
    


}

