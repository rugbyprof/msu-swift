//
//  ViewController.swift
//  Swift Calorie Counter
//
//  Created by John Bura on 9/22/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtTotalCalories: UITextField!
    
    @IBOutlet weak var lblBreakfast: UILabel!
    @IBOutlet weak var lblLunch: UILabel!
    @IBOutlet weak var lblSnacks: UILabel!
    @IBOutlet weak var lblDinner: UILabel!
    @IBOutlet weak var lblDessert: UILabel!
    @IBOutlet weak var lblTotalCalculatedCalories: UILabel!
   
    
    @IBOutlet weak var sldBreakFast: UISlider!
    @IBOutlet weak var sldLunch: UISlider!
    @IBOutlet weak var sldSnacks: UISlider!
    @IBOutlet weak var sldDinner: UISlider!
    @IBOutlet weak var sldDessert: UISlider!
    
    var totalCalories = ""
    var breakfast : Float = 0
    var lunch : Float = 0
    var snacks : Float = 0
    var dinner : Float = 0
    var dessert : Float = 0
    var totalCalculatedCalories : Float = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

 

    @IBAction func sldBreakfastACTION(sender: UISlider) {
        calculateCalories()
    }

    @IBAction func sldLunchACTION(sender: UISlider) {
        calculateCalories()
    }
    
    @IBAction func sldSnacksACTION(sender: UISlider) {
        calculateCalories()
    }
    
    @IBAction func sldDinnerACTION(sender: UISlider) {
        calculateCalories()
    }
    
    @IBAction func sldDessert(sender: UISlider) {
        calculateCalories()

    }
    
    func calculateCalories() -> Bool{
        totalCalories = txtTotalCalories.text
        
        var fTotalCalories = (totalCalories as NSString).floatValue
        
        breakfast = sldBreakFast.value
        lunch = sldLunch.value
        snacks = sldSnacks.value
        dinner = sldDessert.value
        dessert = sldDessert.value
        
        var totalCaloriesPercent = breakfast + lunch + snacks + dinner + dessert
        
        totalCalculatedCalories = fTotalCalories * totalCalculatedCalories
        
        var formatTotalCalculatedCalories : NSString = NSString(format: "%0.0f", totalCalculatedCalories)
        
        lblTotalCalculatedCalories.text = "\(fTotalCalories) cal "
        
        
        
        return true
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtTotalCalories.resignFirstResponder()
    }
    
    
}

