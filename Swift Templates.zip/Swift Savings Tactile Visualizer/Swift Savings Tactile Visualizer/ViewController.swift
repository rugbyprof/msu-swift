//
//  ViewController.swift
//  Swift Savings Tactile Visualizer
//
//  Created by John Bura on 9/20/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var txtYearlyIncome: UITextField!
    
    @IBOutlet weak var lblMonthlyIncome: UILabel!
    @IBOutlet weak var lblRent: UILabel!
    @IBOutlet weak var lblFood: UILabel!
    @IBOutlet weak var lblCarTransportation: UILabel!
    @IBOutlet weak var lblEntertainment: UILabel!
    @IBOutlet weak var lblMisc: UILabel!
    
    @IBOutlet weak var sldRent: UISlider!
    @IBOutlet weak var sldFood: UISlider!
    @IBOutlet weak var sldCarTransportation: UISlider!
    @IBOutlet weak var sldEntertainment: UISlider!
    @IBOutlet weak var sldMisc: UISlider!
    
    var yearlyIncome = ""
    var monthlyIncome : Float = 0
    var rent : Float = 0
    var food : Float = 0
    var carTransportation : Float = 0
    var entertainment : Float = 0
    var misc : Float = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnCalculate(sender: UIButton) {
        calculateExpenses()
    }
    @IBAction func btnClear(sender: UIButton) {
        txtYearlyIncome.text = ""
        lblCarTransportation.text = "$$$$"
        lblEntertainment.text  = "$$$$"
        lblFood.text = "$$$$"
        lblMisc.text = "$$$$"
        lblMonthlyIncome.text = "$$$$"
        lblRent.text = "$$$$"
        
    }
    
    
    @IBAction func sldRentACTION(sender: UISlider) {
        calculateExpenses()
    }
    @IBAction func sldFoodACTION(sender: UISlider) {
        calculateExpenses()
    }
    @IBAction func sldCarTransportationACTION(sender: UISlider) {
        calculateExpenses()
    }
    @IBAction func sldEntertainmentACTION(sender: UISlider) {
        calculateExpenses()
    }
    @IBAction func sldMisc(sender: UISlider) {
        calculateExpenses()
    }
    
    func calculateExpenses() -> Bool{
        yearlyIncome = txtYearlyIncome.text
        
        var fYearlyIncome = (yearlyIncome as NSString).floatValue
        
        monthlyIncome = fYearlyIncome / 12
        
        rent = monthlyIncome * sldRent.value
        food = monthlyIncome * sldFood.value
        carTransportation = monthlyIncome * sldCarTransportation.value
        entertainment = monthlyIncome * sldEntertainment.value
        misc = monthlyIncome * sldMisc.value
        
        var formatRent : NSString = NSString(format: "%0.0f", rent)
        var formatFood : NSString = NSString(format: "%0.0f", food)
        var formatCarTransportation : NSString = NSString(format: "%0.0f", carTransportation)
        var formatEntertainment : NSString = NSString(format: "%0.0f", entertainment)
        var formatMisc : NSString = NSString(format: "%0.0f", misc)
        
        lblMonthlyIncome.text = "$\(monthlyIncome)"
        lblRent.text = "$\(formatRent)"
        lblFood.text = "$\(formatFood)"
        lblCarTransportation.text = "$\(formatCarTransportation)"
        lblEntertainment.text = "$\(formatEntertainment)"
        lblMisc.text = "$\(formatMisc)"
        
        return true
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtYearlyIncome.resignFirstResponder()
    }
    
    

}

