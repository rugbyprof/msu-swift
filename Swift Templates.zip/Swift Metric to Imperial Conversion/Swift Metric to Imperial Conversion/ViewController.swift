//
//  ViewController.swift
//  Swift Metric to Imperial Conversion
//
//  Created by John Bura on 9/26/14.
//  Copyright (c) 2014 Mammoth Interactive. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var swtSwitch: UISwitch!
    
    @IBOutlet weak var lblMetricImperial: UILabel!
    @IBOutlet weak var lblFeetMeters: UILabel!
    @IBOutlet weak var lblMilesKilometers: UILabel!
    @IBOutlet weak var lblGallonsLitres: UILabel!
    @IBOutlet weak var lblPoundsKilograms: UILabel!
    
    @IBOutlet weak var txtFeetMeters: UITextField!
    @IBOutlet weak var txtMilesKilometers: UITextField!
    @IBOutlet weak var txtGallonLitres: UITextField!
    @IBOutlet weak var txtPoundsKilograms: UITextField!
    
    var feet : Float = 0
    var meters : Float  = 0
    
    var miles : Float  = 0
    var kilometers : Float  = 0
    
    var gallons : Float  = 0
    var litres : Float  = 0
    
    var pounds : Float  = 0
    var kilograms : Float  = 0
    
    var feetMeters = ""
    var milesKilometers = ""
    var gallonsLitres = ""
    var poundKilograms = ""
    
    var isMetric = false

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClear(sender: UIButton) {
        txtFeetMeters.text = ""
        txtGallonLitres.text = ""
        txtMilesKilometers.text = ""
        txtPoundsKilograms.text = ""
        
        lblMetricImperial.text = "Imperial"
        isMetric = false
        
        swtSwitch.setOn(false , animated: false)
        
        lblFeetMeters.text = "Feet / Meters"
        lblMilesKilometers.text = "Miles / Kilometers"
        lblGallonsLitres.text = "Gallons / Litres"
        lblPoundsKilograms.text = "Pounds / Kilograms"
        
    }
    
    @IBAction func BtnCalculate(sender: UIButton) {
        convertUnits()
    }
    
    @IBAction func swtSwitchACTION(sender: UISwitch) {
        if swtSwitch.on{
            isMetric = true
            lblMetricImperial.text = "Metric"
        }
        else{
            isMetric = false
            lblMetricImperial.text = "Imperial"
        }
    }
    
    func convertUnits() -> Bool{
        feetMeters = txtFeetMeters.text
        milesKilometers = txtMilesKilometers.text
        gallonsLitres = txtGallonLitres.text
        poundKilograms = txtPoundsKilograms.text
        
        var fFeetMeters = (feetMeters as NSString).floatValue
        var fMilesKilometers  = (milesKilometers as NSString).floatValue
        var fGallonsLitres = (gallonsLitres as NSString).floatValue
        var fPoundKilograms = (poundKilograms as NSString).floatValue
        
        if isMetric == false {
            feet = fFeetMeters
            miles = fMilesKilometers
            gallons = fGallonsLitres
            pounds = fPoundKilograms
            
            meters = feet  * 0.304
            kilometers = miles  * 1.609
            litres = gallons * 3.785
            kilograms = pounds * 0.453
            
            var formatFeet : NSString = NSString(format: "%0.2f", feet)
            var formatMiles : NSString = NSString(format: "%0.2f", miles)
            var formatGallons : NSString = NSString(format: "%0.2f", gallons)
            var formatPounds : NSString = NSString(format: "%0.2f", pounds)
            
            var formatMeters : NSString = NSString(format: "%0.2f", meters)
            var formatKilometers : NSString = NSString(format: "%0.2f", kilometers)
            var formatLitres : NSString = NSString(format: "%0.2f", litres)
            var formatKilograms : NSString = NSString(format: "%0.2f", kilograms)
            
            lblFeetMeters.text = "\(formatFeet) feet is \(formatMeters) meters"
            lblMilesKilometers.text = "\(formatMiles) miles is \(formatKilometers) kilometers"
            lblGallonsLitres.text = "\(formatGallons) gallons is \(formatLitres) litres"
            lblPoundsKilograms.text = "\(formatPounds) pounds is \(formatKilograms) kilograms"
            
            
        }
        
        if isMetric == true{
            meters = fFeetMeters
            kilometers = fMilesKilometers
            litres = fGallonsLitres
            kilograms = fPoundKilograms
            
            feet = meters * 3.28
            miles = kilometers * 0.621
            gallons = litres * 0.264
            pounds = kilograms * 2.204
            
            var formatFeet : NSString = NSString(format: "%0.2f", feet)
            var formatMiles : NSString = NSString(format: "%0.2f", miles)
            var formatGallons : NSString = NSString(format: "%0.2f", gallons)
            var formatPounds : NSString = NSString(format: "%0.2f", pounds)
            
            var formatMeters : NSString = NSString(format: "%0.2f", meters)
            var formatKilometers : NSString = NSString(format: "%0.2f", kilometers)
            var formatLitres : NSString = NSString(format: "%0.2f", litres)
            var formatKilograms : NSString = NSString(format: "%0.2f", kilograms)
            
            lblFeetMeters.text = "\(formatFeet) feet is \(formatMeters) meters"
            lblMilesKilometers.text = "\(formatMiles) miles is \(formatKilometers) kilometers"
            lblGallonsLitres.text = "\(formatGallons) gallons is \(formatLitres) litres"
            lblPoundsKilograms.text = "\(formatPounds) pounds is \(formatKilograms) kilograms"
            
        }
        
        
        
        return true
        
    }
    
    override func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        txtFeetMeters.resignFirstResponder()
        txtGallonLitres.resignFirstResponder()
        txtMilesKilometers.resignFirstResponder()
        txtPoundsKilograms.resignFirstResponder()
    }

}

